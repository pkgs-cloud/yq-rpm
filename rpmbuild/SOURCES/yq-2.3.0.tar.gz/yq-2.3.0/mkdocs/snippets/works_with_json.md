This command can take a json file as input too, and will output yaml unless specified to export as json (-j)
