#!/bin.bash

brew install mkdocs libyaml
pip3 install markdown-include
pip3 install mkdocs-material

